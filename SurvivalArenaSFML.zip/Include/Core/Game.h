#pragma once

#include <SFML/Graphics.hpp>
#include <vector>
#include <memory>

#include "Config/GameConfig.h"
#include "Entities/Enemy.h"
#include "Enemies/Zombie.h"
#include "Entities/Player.h"

class Game {

	private:

		sf::RenderWindow window_;
		Player player_;
		std::vector<std::unique_ptr<Enemy>> enemies_;

	public:

		//Constructor
		Game();

		//Core
		bool IsRunning()const;

		void ProcessEvents();
		void Update(float dt);
		void Render();
};